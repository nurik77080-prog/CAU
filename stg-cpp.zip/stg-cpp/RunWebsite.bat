@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>nul
if not errorlevel 1 (
  node.exe web\server.cjs --open
  goto finish
)
set "STG_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%STG_NODE%" (
  "%STG_NODE%" web\server.cjs --open
  goto finish
)
echo Install Node.js 20 or newer, then open RunWebsite.bat again.
:finish
if errorlevel 1 pause
endlocal
