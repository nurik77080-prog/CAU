#pragma once
#include <windows.h>
#include <bcrypt.h>
#include <string>
#include <vector>
#include <stdexcept>
#include <cstring>

inline std::string passwordDigest(const std::string &password, const std::string &saltHex) {
    HMODULE library = LoadLibraryExW(L"bcrypt.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!library) throw std::runtime_error("Password service unavailable.");
    decltype(&BCryptOpenAlgorithmProvider) open;
    FARPROC address = GetProcAddress(library, "BCryptOpenAlgorithmProvider");
    std::memcpy(&open, &address, sizeof(open));
    decltype(&BCryptDeriveKeyPBKDF2) derive;
    address = GetProcAddress(library, "BCryptDeriveKeyPBKDF2");
    std::memcpy(&derive, &address, sizeof(derive));
    decltype(&BCryptCloseAlgorithmProvider) close;
    address = GetProcAddress(library, "BCryptCloseAlgorithmProvider");
    std::memcpy(&close, &address, sizeof(close));
    if (!open || !derive || !close) {
        FreeLibrary(library);
        throw std::runtime_error("Password service unavailable.");
    }
    std::vector<unsigned char> salt;
    for (int i = 0; i + 1 < (int)saltHex.size(); i += 2)
        salt.push_back((unsigned char)std::stoul(saltHex.substr(i, 2), nullptr, 16));
    BCRYPT_ALG_HANDLE algorithm = nullptr;
    if (open(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, BCRYPT_ALG_HANDLE_HMAC_FLAG) < 0) {
        FreeLibrary(library);
        throw std::runtime_error("Password service unavailable.");
    }
    unsigned char hash[32];
    NTSTATUS result = derive(algorithm, (PUCHAR)password.data(), (ULONG)password.size(),
        salt.data(), (ULONG)salt.size(), 600000, hash, sizeof(hash), 0);
    close(algorithm, 0);
    FreeLibrary(library);
    if (result < 0) throw std::runtime_error("Password service unavailable.");
    std::string text;
    const char *digits = "0123456789abcdef";
    for (int i = 0; i < 32; i++) {
        text += digits[hash[i] / 16];
        text += digits[hash[i] % 16];
    }
    return text;
}

inline bool checkPassword(int role, const std::string &password) {
    std::string salt, expected;
    if (role == 1) {
        salt = "ee629e569f5f4aa60f373a777fce30e0";
        expected = "1063fede92bc6d95a50fd32804ef96976a0304de47609218ab5d1437d069a8df";
    } else {
        salt = "ca5ee899658d4dea90e5adb623653acc";
        expected = "e3351997816ab68118e683b98b9d9d3a977cb10d235fac65ed05d503415992da";
    }
    std::string actual = passwordDigest(password, salt);
    unsigned int difference = 0;
    for (int i = 0; i < 64; i++) difference |= actual[i] ^ expected[i];
    return difference == 0;
}

