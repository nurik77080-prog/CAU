# Campus Ledger artwork and type

Website assets live in web/dist. The original campus illustration, register, gradebook and calendar icons were drawn for this project. The campus reading room and course still lifes were made with the built-in ImageGen tool.

- Campus reading room: web/dist/campus-life.webp
- Calculus still life: web/dist/calculus.webp
- Computer Engineering still life: web/dist/engineering.webp
- Physics still life: web/dist/physics.webp

Campus image prompt:

Create a refined wide editorial illustration for the hero of a university academic workspace website. A cutaway isometric campus reading room, an airy library with a handful of university students studying at desks, open notebooks, a stairway and bookshelves, a glimpse of trees outside. Every element feels observed and drawn by a human editorial illustrator, bold selective navy outlines with restrained flat shading, warm ivory paper grain, sage green, muted coral sunlight and a few cobalt accents. Peaceful academic life in Tashkent, contemporary university students, natural proportions. Architectural diorama occupies the central and right portion, feathering cleanly into a pale sage background (#e9eee4) toward all edges. A single cohesive landscape-format image, 2:1 composition, cropped for a wide banner. No text, lettering, labels, logos, watermarks, screens of a fake interface, or borders.

Course atlas prompt:

Create one wide editorial illustration called a course atlas for a university gradebook. It is a single horizontal triptych, three precisely equal-width adjacent vertical panels with hard boundaries at one third and two thirds. No margins, gutters or frames. Each panel is a distinct beautifully lit still-life, tactile natural materials, subtle paper grain and mid-century art direction. LEFT PANEL: a blue-bound graph notebook with a bold blue curve drawn across the paper, and one brass drafting compass resting diagonally, on pale powder-blue paper. CENTER PANEL: a small exquisitely detailed terracotta and copper printed circuit board with a dark microchip at a 3/4 angle on warm amber paper. RIGHT PANEL: a solid triangular glass optical prism splitting a soft beam into a small spectrum on lavender paper. Objects stay entirely inside their own third; place the focal objects on the middle horizontal band of the image. Sophisticated authentic objects, soft shadows, slight top-down angle, restrained art direction. No letters, words, numbers, labels, people, watermarks or logos. Wide 3:1 composition.

Fraunces and Manrope are self-hosted Google Fonts. Their SIL Open Font Licenses are in web/dist/fraunces-license.txt and web/dist/manrope-license.txt.

App design reference: [CAU App by Eduplus](https://play.google.com/store/apps/details?id=uz.akfa.eduplus).
