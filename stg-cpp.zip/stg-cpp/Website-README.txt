CAMPUS LEDGER / STG

ISHGA TUSHIRISH
1. Konsolda ishlayotgan main.exe dasturini yoping. Konsol va sayt bir vaqtda yozsa, biri ikkinchisining eski nusxasini saqlashi mumkin.
2. RunWebsite.bat faylini ikki marta bosing. Brauzer avtomatik ochiladi. Oyna ochilmasa, konsoldagi http://127.0.0.1:... manzilni oching.
3. Professor yoki Student rolini tanlang. Konsoldagi o‘sha parolni ishlating; talaba uchun ID ham kerak.
4. Saytni yopish uchun server oynasida Ctrl+C bosing.

MA’LUMOTLAR
Saytni ishlatish uchun Node.js 20+ yoki shu kompyuterdagi Codex Node muhiti kerak. Qo‘shimcha paket yoki internet kerak emas. web/server.cjs faqat 127.0.0.1 manzilida ishlaydi. Saytda saqlangan o‘zgarishlarni o‘sha main.exe asl students.txt fayliga yozadi. Keyingi safar konsolni ochsangiz ham shu natijalar ko‘rinadi. Professor talaba, baho va davomatni qo‘shishi, tahrirlashi yoki o‘chirishi mumkin. Talaba faqat o‘z baholari va davomatini ko‘radi.

«Explore with sample data» — alohida demo. Bu rejimda ma’lumot faqat brauzerda saqlanadi. Demo menyusida professor yoki talaba ko‘rinishini tanlashingiz mumkin; «Return to STG sign-in» haqiqiy ro‘yxatga kirish sahifasiga qaytaradi.

Manba: CAU App (Eduplus), https://play.google.com/store/apps/details?id=uz.akfa.eduplus . Campus Ledger — ushbu kurs loyihasining mustaqil interfeysi.
