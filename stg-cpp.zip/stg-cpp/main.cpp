#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <conio.h>
#include "password.h"
using namespace std;

// Har bir bahoda fan raqami va olingan ball saqlanadi.
struct Grade {
    int subject;
    int score;
};

// Davomat: sana, fan va qatnashish holati.
struct Attendance {
    string date;
    int subject;
    int status;
};

// Talabaning malumotlari, baholari va davomati.
struct Student {
    string id;
    string name;
    vector<Grade> grades;
    vector<Attendance> attendance;
};

string subjects[] = {"Unassigned", "Calculus", "Computer Engineering", "Physics"};
string statuses[] = {"", "Present", "Absent", "Late"};
vector<Student> students = {
    {"260600", "muhammadayub umarov", {{1, 100}, {3, 67}, {2, 67}, {1, 100}, {0, 67}, {0, 67}, {0, 67}, {0, 67}, {0, 67}, {0, 67}, {0, 67}}, {}},
    {"260026", "otabek ibragimov", {{0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}, {0, 1}}, {}},
    {"260551", "islamov nurmuhammad", {{0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {0, 100}, {1, 99}}, {}}
};

// Matn butun son ekanligini tekshiramiz.
bool parseNumber(string text, int &value) {
    stringstream input(text);
    char extra;
    if (!(input >> value)) {
        return false;
    }
    if (input >> extra) {
        return false;
    }
    return true;
}

string readText(string prompt) {
    string text;
    cout << prompt;
    getline(cin, text);
    return text;
}

int readNumber(string prompt) {
    int value;
    while (cin) {
        string text = readText(prompt);
        if (!cin) {
            break;
        }
        if (parseNumber(text, value)) {
            return value;
        }
        cout << "Enter a whole number.\n";
    }
    return -1;
}

// Konsolda parol belgilarini yulduzcha bilan korsatamiz.
string readPassword() {
    cout << "Password: ";
    if (GetFileType(GetStdHandle(STD_INPUT_HANDLE)) != FILE_TYPE_CHAR) {
        string text;
        getline(cin, text);
        return text;
    }
    string password;
    while (true) {
        int c = _getch();
        if (c == 13) {
            break;
        }
        if (c == 3) {
            cin.setstate(ios::eofbit);
            break;
        }
        if (c == 0 || c == 224) {
            _getch();
            continue;
        }
        if (c == 8 && !password.empty()) {
            password.pop_back();
            cout << "\b \b";
        } else if (c >= 32 && c < 127 && password.size() < 128) {
            password += char(c);
            cout << '*';
        }
    }
    cout << '\n';
    return password;
}

bool validId(string id) {
    if (id.empty() || id.size() > 32) {
        return false;
    }
    for (char c : id) {
        if (c < '0' || c > '9') return false;
    }
    return true;
}

bool validName(string name) {
    if (name.size() > 180 || name.find_first_not_of(" \t\r\n") == string::npos) {
        return false;
    }
    for (unsigned char c : name) {
        if (c < 32 || c == 127) return false;
    }
    return true;
}

// ID boyicha talabani qidiramiz. Topilmasa -1 qaytadi.
int findStudent(string id) {
    for (int i = 0; i < (int)students.size(); i++)
        if (students[i].id == id) {
            return i;
        }
    return -1;
}

int askStudent() {
    int index = findStudent(readText("Student ID: "));
    if (index == -1) {
        cout << "Student not found.\n";
    }
    return index;
}

// Oy va kabisa yilini hisobga olib sanani tekshiramiz.
bool validDate(string date) {
    if (date.size() != 10 || date[4] != '-' || date[7] != '-') {
        return false;
    }
    for (int i = 0; i < 10; i++)
        if (i != 4 && i != 7 && (date[i] < '0' || date[i] > '9')) {
            return false;
        }
    int year = stoi(date.substr(0, 4));
    int month = stoi(date.substr(5, 2));
    int day = stoi(date.substr(8, 2));
    if (year < 1900 || month < 1 || month > 12) {
        return false;
    }
    int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
        days[1] = 29;
    }
    return day >= 1 && day <= days[month - 1];
}

// Avval vaqtinchalik faylga yozamiz, keyin asosiy faylni yangilaymiz.
bool saveData() {
    ofstream file("students.tmp");
    if (!file) {
        return false;
    }
    file << "STG_CPP_1\n" << students.size() << '\n';
    for (int item1 = 0; item1 < (int)students.size(); item1++) {
        Student student = students[item1];
        file << student.id << '\n' << student.name << '\n' << student.grades.size() << '\n';
        for (int item2 = 0; item2 < (int)student.grades.size(); item2++) {
            Grade grade = student.grades[item2];
            file << grade.subject << ' ' << grade.score << '\n';
        }
        file << student.attendance.size() << '\n';
        for (int item3 = 0; item3 < (int)student.attendance.size(); item3++) {
            Attendance record = student.attendance[item3];
            file << record.date << ' ' << record.subject << ' ' << record.status << '\n';
        }
    }
    file.close();
    if (!file) {
        return false;
    }
    return MoveFileExA("students.tmp", "students.txt", MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0;
}

// Fayldan talabalar, baholar va davomatni oqiymiz.
bool loadData() {
    ifstream file("students.txt");
    if (!file) {
        return GetFileAttributesA("students.txt") == INVALID_FILE_ATTRIBUTES && GetLastError() == ERROR_FILE_NOT_FOUND;
    }
    string header;
    int count;
    if (!getline(file, header) || header != "STG_CPP_1" || !(file >> count) || count < 0) {
        return false;
    }
    vector<Student> loaded;
    for (int i = 0; i < count; i++) {
        Student student;
        int size;
        file.ignore(10000, '\n');
        if (!getline(file, student.id) || !getline(file, student.name)) {
            return false;
        }
        if (!validId(student.id) || !validName(student.name)) {
            return false;
        }
        for (int item4 = 0; item4 < (int)loaded.size(); item4++) {
            Student previous = loaded[item4];
            if (previous.id == student.id) {
                return false;
            }
        }
        if (!(file >> size) || size < 0) {
            return false;
        }
        for (int j = 0; j < size; j++) {
            Grade grade;
            if (!(file >> grade.subject >> grade.score)) {
                return false;
            }
            if (grade.subject < 0 || grade.subject > 3 || grade.score < 0 || grade.score > 100) {
                return false;
            }
            student.grades.push_back(grade);
        }
        if (!(file >> size) || size < 0) {
            return false;
        }
        for (int j = 0; j < size; j++) {
            Attendance record;
            if (!(file >> record.date >> record.subject >> record.status)) {
                return false;
            }
            if (!validDate(record.date) || record.subject < 1 || record.subject > 3 || record.status < 1 || record.status > 3) {
                return false;
            }
            for (int item5 = 0; item5 < (int)student.attendance.size(); item5++) {
                Attendance previous = student.attendance[item5];
                if (previous.date == record.date && previous.subject == record.subject) {
                    return false;
                }
            }
            student.attendance.push_back(record);
        }
        loaded.push_back(student);
    }
    file >> ws;
    if (!file.eof() || file.bad()) {
        return false;
    }
    students = loaded;
    return true;
}

// Saqlash ishlamasa, oldingi malumotlarni qaytaramiz.
void finishChange(vector<Student> previous) {
    if (saveData()) {
        cout << "Saved.\n";
    }
    else {
        students = previous;
        cout << "Cannot save. Change cancelled.\n";
    }
}

char letterGrade(int score) {
    if (score >= 90) {
        return 'A';
    }
    if (score >= 80) {
        return 'B';
    }
    if (score >= 70) {
        return 'C';
    }
    if (score >= 60) {
        return 'D';
    }
    return 'F';
}

// Baholarni chiqarib, ortacha, eng katta va eng kichik ballni topamiz.
void showGrades(int index, int subject = -1, bool recent = false) {
    Student student = students[index];
    cout << "\nID: " << student.id << "\nName: " << student.name << '\n';
    double sum = 0;
    int count = 0, highest = 0, lowest = 100;
    int start = 0;
    if (recent && student.grades.size() > 4) {
        start = (int)student.grades.size() - 4;
    }
    for (int position = start; position < (int)student.grades.size(); position++) {
        int i = position;
        if (recent) {
            i = (int)student.grades.size() - 1 - (position - start);
        }
        Grade grade = student.grades[i];
        if (subject != -1 && grade.subject != subject) {
            continue;
        }
        cout << i + 1 << ". " << subjects[grade.subject] << ": " << grade.score << " / 100 (" << letterGrade(grade.score) << ")\n";
        sum += grade.score;
        count++;
        if (grade.score > highest) {
            highest = grade.score;
        }
        if (grade.score < lowest) {
            lowest = grade.score;
        }
    }
    if (count == 0) {
        cout << "No grades yet.\n";
    }
    else cout << "Grades: " << count << "\nAverage: " << fixed << setprecision(2) << sum / count
              << "\nHighest: " << highest << "\nLowest: " << lowest << '\n';
}

void showAttendance(int index) {
    int present = 0, absent = 0, late = 0;
    cout << "\nAttendance: " << students[index].name << '\n';
    for (int i = 0; i < (int)students[index].attendance.size(); i++) {
        Attendance record = students[index].attendance[i];
        cout << i + 1 << ". " << record.date << " | " << subjects[record.subject] << " | " << statuses[record.status] << '\n';
        if (record.status == 1) {
            present++;
        }
        if (record.status == 2) {
            absent++;
        }
        if (record.status == 3) {
            late++;
        }
    }
    int total = present + absent + late;
    if (total == 0) {
        cout << "No attendance yet.\n";
    }
    else cout << "Present: " << present << " | Absent: " << absent << " | Late: " << late
              << "\nAttendance (present + late): " << fixed << setprecision(1) << 100.0 * (present + late) / total << "%\n";
}

int chooseSubject() {
    return readNumber("1. Calculus\n2. Computer Engineering\n3. Physics\nSubject: ");
}

void addStudent() {
    Student student;
    student.id = readText("Student ID: ");
    if (!validId(student.id) || findStudent(student.id) != -1) {
        cout << "ID must contain digits and must be unique.\n";
        return;
    }
    student.name = readText("Full name: ");
    if (!validName(student.name)) {
        cout << "Invalid name.\n";
        return;
    }
    vector<Student> previous = students;
    students.push_back(student);
    finishChange(previous);
}

void changeStudent(bool remove) {
    int index = askStudent();
    if (index == -1) {
        return;
    }
    vector<Student> previous = students;
    if (remove) {
        if (readText("Delete student and all records? (yes/no): ") != "yes") {
            return;
        }
        students.erase(students.begin() + index);
    } else {
        string name = readText("New full name: ");
        if (!validName(name)) {
            cout << "Invalid name.\n";
            return;
        }
        students[index].name = name;
    }
    finishChange(previous);
}

void addGrades() {
    int index = askStudent();
    if (index == -1) {
        return;
    }
    int subject = chooseSubject();
    if (subject < 1 || subject > 3) {
        cout << "Invalid subject.\n";
        return;
    }
    while (cin) {
        string text = readText("Grade (0-100), or done to cancel: ");
        if (!cin || text == "done") {
            break;
        }
        int score;
        if (!parseNumber(text, score) || score < 0 || score > 100) {
            cout << "Invalid grade.\n";
            continue;
        }
        vector<Student> previous = students;
        Grade grade;
        grade.subject = subject;
        grade.score = score;
        students[index].grades.push_back(grade);
        finishChange(previous);
        return;
    }
}

void changeGrade(bool remove) {
    int index = askStudent();
    if (index == -1) {
        return;
    }
    showGrades(index);
    int number = readNumber("Grade number: ");
    if (number < 1 || number > (int)students[index].grades.size()) {
        cout << "Invalid grade number.\n";
        return;
    }
    vector<Student> previous = students;
    if (remove) {
        if (readText("Delete grade? (yes/no): ") != "yes") {
            return;
        }
        students[index].grades.erase(students[index].grades.begin() + number - 1);
    } else {
        int subject = chooseSubject();
        int score = readNumber("New grade (0-100): ");
        if (subject < 1 || subject > 3 || score < 0 || score > 100) {
            cout << "Invalid grade or subject.\n";
            return;
        }
        students[index].grades[number - 1].subject = subject;
        students[index].grades[number - 1].score = score;
    }
    finishChange(previous);
}

// Shu sana va fan bor bolsa yangilaymiz, aks holda yangi yozuv qoshamiz.
void markAttendance() {
    int index = askStudent();
    if (index == -1) {
        return;
    }
    string date = readText("Date (YYYY-MM-DD): ");
    if (!validDate(date)) {
        cout << "Invalid date.\n";
        return;
    }
    int subject = chooseSubject();
    int status = readNumber("1. Present\n2. Absent\n3. Late\nStatus: ");
    if (subject < 1 || subject > 3 || status < 1 || status > 3) {
        cout << "Invalid subject or status.\n";
        return;
    }
    int position = -1;
    for (int i = 0; i < (int)students[index].attendance.size(); i++) {
        Attendance record = students[index].attendance[i];
        if (record.date == date && record.subject == subject) {
            position = i;
        }
    }
    vector<Student> previous = students;
    if (position == -1) {
        Attendance record;
        record.date = date;
        record.subject = subject;
        record.status = status;
        students[index].attendance.push_back(record);
    }
    else students[index].attendance[position].status = status;
    finishChange(previous);
}

void deleteAttendance() {
    int index = askStudent();
    if (index == -1) {
        return;
    }
    showAttendance(index);
    int number = readNumber("Attendance number: ");
    if (number < 1 || number > (int)students[index].attendance.size()) {
        cout << "Invalid number.\n";
        return;
    }
    if (readText("Delete attendance? (yes/no): ") != "yes") {
        return;
    }
    vector<Student> previous = students;
    students[index].attendance.erase(students[index].attendance.begin() + number - 1);
    finishChange(previous);
}

void showStatistics() {
    int count = 0, graded = 0;
    int distribution[5] = {};
    double sum = 0;
    for (int item6 = 0; item6 < (int)students.size(); item6++) {
        Student student = students[item6];
        if (!student.grades.empty()) {
            graded++;
        }
        for (int item7 = 0; item7 < (int)student.grades.size(); item7++) {
            Grade grade = student.grades[item7];
            count++;
            sum += grade.score;
            int group = 0;
            if (grade.score >= 90) {
                group = 4;
            }
            else if (grade.score >= 80) {
                group = 3;
            }
            else if (grade.score >= 70) {
                group = 2;
            }
            else if (grade.score >= 60) {
                group = 1;
            }
            distribution[group]++;
        }
    }
    cout << "Students: " << students.size() << "\nStudents with grades: " << graded << "\nTotal grades: " << count << '\n';
    if (count > 0) {
        cout << "Overall average: " << fixed << setprecision(2) << sum / count << '\n';
    }
    string labels[] = {"0-59", "60-69", "70-79", "80-89", "90-100"};
    for (int i = 0; i < 5; i++) {
        cout << labels[i] << ": " << distribution[i] << '\n';
    }
}

// Oqituvchi menyusi tanlangan amalni chaqiradi.
void professorMenu() {
    while (cin) {
        cout << "\nPROFESSOR\n1. Add Student\n2. Add Grades\n3. All Students\n4. Search Student\n";
        cout << "5. Average and Results\n6. Save\n7. Edit Student\n8. Delete Student\n9. Edit Grade\n10. Delete Grade\n";
        cout << "11. Statistics\n12. Mark / Update Attendance\n13. View Attendance\n14. Delete Attendance\n0. Log Out\n";
        int choice = readNumber("Choice: ");
        if (!cin || choice == 0) {
            return;
        }
        if (choice == 1) {
            addStudent();
        }
        else if (choice == 2) {
            addGrades();
        }
        else if (choice == 3) {
            if (students.empty()) {
                cout << "No students.\n";
            }
            for (int i = 0; i < (int)students.size(); i++) {
                showGrades(i);
            }
        } else if (choice == 4 || choice == 5) {
            int index = askStudent();
            if (index != -1) {
                showGrades(index);
            }
        } else if (choice == 6) {
            if (saveData()) {
                cout << "Saved.\n";
            } else {
                cout << "Cannot save.\n";
            }
        }
        else if (choice == 7) {
            changeStudent(false);
        }
        else if (choice == 8) {
            changeStudent(true);
        }
        else if (choice == 9) {
            changeGrade(false);
        }
        else if (choice == 10) {
            changeGrade(true);
        }
        else if (choice == 11) {
            showStatistics();
        }
        else if (choice == 12) {
            markAttendance();
        }
        else if (choice == 13) {
            int index = askStudent();
            if (index != -1) {
                showAttendance(index);
            }
        } else if (choice == 14) deleteAttendance();
        else cout << "Invalid choice.\n";
    }
}

// Talaba oz baholari va davomatini koradi.
void studentMenu(int index) {
    while (cin) {
        cout << "\nSTUDENT: " << students[index].name << "\n1. My Results\n2. Results by Subject\n3. Recent Grades\n4. My Attendance\n0. Log Out\n";
        int choice = readNumber("Choice: ");
        if (!cin || choice == 0) {
            return;
        }
        if (choice == 1) {
            showGrades(index);
        }
        else if (choice == 2) {
            cout << "0. Unassigned\n";
            int subject = chooseSubject();
            if (subject >= 0 && subject <= 3) {
                showGrades(index, subject);
            }
            else cout << "Invalid subject.\n";
        } else if (choice == 3) showGrades(index, -1, true);
        else if (choice == 4) {
            showAttendance(index);
        }
        else cout << "Invalid choice.\n";
    }
}

// Dastur shu yerdan boshlanadi.
int main() {
    if (!loadData()) {
        cout << "Cannot read students.txt.\n";
        return 1;
    }
    int attempts[3] = {};
    ULONGLONG blockedUntil[3] = {};
    while (cin) {
        cout << "\nCAU STUDENT SERVICE\n1. Professor\n2. Student\n0. Exit\n";
        int role = readNumber("Choice: ");
        if (!cin || role == 0) {
            break;
        }
        if (role != 1 && role != 2) {
            cout << "Invalid choice.\n";
            continue;
        }
        if (GetTickCount64() < blockedUntil[role]) {
            cout << "Too many attempts. Try again in one minute.\n";
            continue;
        }
        string id;
        if (role == 2) {
            id = readText("Student ID: ");
        }
        string password = readPassword();
        if (!cin) {
            break;
        }
        bool valid = false;
        try { valid = checkPassword(role, password); }
        catch (const exception &error) {
            cout << error.what() << '\n';
            continue;
        }
        int index = findStudent(id);
        if (!valid || (role == 2 && index == -1)) {
            cout << "Incorrect login.\n";
            attempts[role]++;
            if (attempts[role] >= 5) {
                blockedUntil[role] = GetTickCount64() + 60000;
                attempts[role] = 0;
            }
            continue;
        }
        attempts[role] = 0;
        if (role == 1) {
            professorMenu();
        }
        else studentMenu(index);
    }
    return 0;
}


